export class Filme{
    id: number;
    nome: string;
    lancamento: string;
    popularidade: string;
    }
	
	
/**
 * Nome: Claudemir Cardoso RA:816155452
 */