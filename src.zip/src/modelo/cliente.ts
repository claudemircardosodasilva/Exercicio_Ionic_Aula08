export class Cliente{
    id: number;
    nome: string;
    fone: string;
    email: string;
    }
	
	
/**
 * Nome: Claudemir Cardoso RA:816155452
 */