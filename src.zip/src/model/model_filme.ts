
 

export interface Filme {
    nome: string;
    descricao: string;
}

export interface Genero {
    nome: string;
    genero: string;
}

/**
 * Nome: Claudemir Cardoso RA:816155452
 */